package hcmute.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import hcmute.entity.AuthorEntity_21110559;

public class AuthorDAO_21110559 extends AbstractDAO_21110559<AuthorEntity_21110559>{

}
