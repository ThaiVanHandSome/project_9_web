package hcmute.dao;

import hcmute.entity.UsersEntity_21110559;

public class UserDAO_21110559 extends AbstractDAO_21110559<UsersEntity_21110559>{

}
